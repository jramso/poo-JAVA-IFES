package domain;

public enum Categoria {
    
    COMEDIA,
    ACAO,
    AVENTURA,
    DRAMA,
    VIOLENCIA,
    SEXO,
    LINGUAGEM;
}
