package UI;

public abstract class Form {
    public abstract void exibe();
}
