package CDU;

public abstract class CDU {
    public abstract void exec();

}
